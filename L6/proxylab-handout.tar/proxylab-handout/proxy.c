#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv [])
{
    printf ("Hi! I am a proxy. But I do nothing.\n");
    return 0;
}

